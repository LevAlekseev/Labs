from deap import base
from deap import creator
from deap import tools

import random

import matplotlib.pyplot as plt
import seaborn as sns

# Параметры популяции
ONE_MAX_LENGTH = 150                                                           # Длина хромосом
POPULATION_SIZE = 500                                                          # Размер популяции
P_CROSSOVER = 0.9                                                              # Вероятность скрещивания
P_MUTATION = 0.1                                                               # Вероятность мутации одного индивида
MAX_GENERATIONS = 100

toolbox = base.Toolbox()

toolbox.register("zeroOrOne", random.randint, 0, 1)                            # Функция заполнения хромосом
creator.create("FitnessMax", base.Fitness, weights=(1.0,))                     # Создание класса целей приспособления индивида
creator.create("Individual", list, fitness=creator.FitnessMax)                 # Создание класса индивида, основанного на списке() и с атрибутом приспособленности

# Функция создания индивидов с параметрами: Индивид, функция заполнения хромосом и максимальная длина хромосомы
toolbox.register("individualCreator", tools.initRepeat, creator.Individual, toolbox.zeroOrOne, ONE_MAX_LENGTH)
toolbox.register("populationCreator", tools.initRepeat, list, toolbox.individualCreator)    # Функция создания популяции

# Подсчет приспособленности (сумма единиц в хромосоме)
def oneMaxFitness(individual):
    return sum(individual),

toolbox.register("evaluate", oneMaxFitness)

toolbox.register("select", tools.selTournament, tournsize=4)                      # Функция турнирного отбора индивидов для создания потомства с размером 4
toolbox.register("mate", tools.cxOnePoint)                                        # Функция одноточечного скрещивания
toolbox.register("mutate", tools.mutFlipBit, indpb=1.0/ONE_MAX_LENGTH)            # Функция мутации - инвертирование одного знака(бита) в хромосоме с вероятностью 1/длинаХромосомы

def main():   
    population = toolbox.populationCreator(n=POPULATION_SIZE)                     #Поколение 0
    generationCounter = 0     

    fitnessValues = list(map(toolbox.evaluate, population))                       # Подсчет значения приспособленности каждого индивида в популяции (хромосомы в функцию закидываем)
    for individual, fitnessValue in zip(population, fitnessValues):               # Заполнение значения приспособленности у каждого индивида
        individual.fitness.values = fitnessValue

    fitnessValues = [individual.fitness.values[0] for individual in population]   # Заполняем список приспособленности, проходя по всей популяции

    # Для графика
    maxFitnessValues = []
    avgFitnessValues = []

    # Цикл поколений, остоновка когда достигли макс. поколения или дошли до самого лучшего решения с текущеми параметрами
    while max(fitnessValues) < ONE_MAX_LENGTH and generationCounter < MAX_GENERATIONS:
        generationCounter = generationCounter + 1
        offspring = toolbox.select(population, len(population))                 # Выбираем лучших индивидов из популяции для скрещивания
        offspring = list(map(toolbox.clone, offspring))

        # Скрещивание индивидов для создания потомства
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < P_CROSSOVER:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values
        # Мутирование генов у потомства с вероятностью 0.1 для каждого потомка
        for mutant in offspring:
            if random.random() < P_MUTATION:
                toolbox.mutate(mutant)
                del mutant.fitness.values

        # Подсчет приспособленности
        freshIndividuals = [ind for ind in offspring if not ind.fitness.valid]
        freshFitnessValues = list(map(toolbox.evaluate, freshIndividuals))
        for individual, fitnessValue in zip(freshIndividuals, freshFitnessValues):
            individual.fitness.values = fitnessValue

        population[:] = offspring

        fitnessValues = [ind.fitness.values[0] for ind in population]
        maxFitness = max(fitnessValues)
        avgFitness = sum(fitnessValues) / len(population)
        maxFitnessValues.append(maxFitness)
        avgFitnessValues.append(avgFitness)
        print("Поколение {}: Макс. приспособленность = {}, Сред. приспособленность = {}".format(generationCounter, maxFitness, avgFitness))

        best_index = fitnessValues.index(max(fitnessValues))
        print("Лучший = ", *population[best_index], "\n")

    # График
    sns.set_style("whitegrid")
    plt.plot(maxFitnessValues, color='red')
    plt.plot(avgFitnessValues, color='green')
    plt.xlabel('Поколения')
    plt.ylabel('Макс (красный) / Сред (зеленый) приспособленности')
    plt.title('Максимальное и среднение приспособленности через поколения')
    plt.show()


main()